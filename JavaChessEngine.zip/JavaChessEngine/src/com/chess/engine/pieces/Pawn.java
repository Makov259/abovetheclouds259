package com.chess.engine.pieces;

import com.chess.engine.Alliance;
import com.chess.engine.board.Board;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.Move;
import com.google.common.collect.ImmutableList;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Pawn  extends  Piece{
    /*-------------------------------------------------Data-------------------------------------------------------------------*/
    private final static  int[] CANDIDATE_MOVE_COORDINATES = {8, 16, 7, 9};

    /*-------------------------------------------------Constructors-------------------------------------------------------------------*/
    public Pawn(final Alliance pieceAlliance, final int piecePosition) {
        super(piecePosition, pieceAlliance);
    }

    /*-------------------------------------------------Abstract Methods-------------------------------------------------------------------*/
    @Override
    public Collection<Move> calculateLegalMoves(final Board board) {
        final List<Move> legalMoves = new ArrayList<>(); //declaring a List of moves.
        for(int currentCandidateOffSet : CANDIDATE_MOVE_COORDINATES){//iterating through our possible options for  offSets
            final int candidateDestinationCoordinate = this.piecePosition + (this.getPieceAlliance().getDirection() * currentCandidateOffSet);// the square we want go = our position + the offset * (1/-1)
            if(!BoardUtils.isValidTileCoordinate(candidateDestinationCoordinate)){//if  square we want go is >= 0 && < 64 continue.
                continue;
            }
            if(currentCandidateOffSet == 8 && !board.getTile(candidateDestinationCoordinate).isTileOccupied()){// if offset is 8 and the square with cdc is NOT occupied , we can move there
                //TODO MORE WORK
                legalMoves.add(new Move.MajorMove(board,this,candidateDestinationCoordinate));
            }else if(currentCandidateOffSet == 16 && this.isFirstMove() &&// if offset =16 AND this is first move of the pawn AND
                    (BoardUtils.SECOND_ROW[this.piecePosition] && this.getPieceAlliance().isBlack()) || //our pawn is on the 2nd row and it's black
                    (BoardUtils.SEVENTH_ROW[this.piecePosition] && this.getPieceAlliance().isWhite())){//our pawn is on the 7th row and it's white
                final int behindCandidateDestinationCoordinate = this.piecePosition + (this.pieceAlliance.getDirection() * 8);//the square behind the candidate = our position + 8 * (1/-1)
                if(!board.getTile(behindCandidateDestinationCoordinate).isTileOccupied() && // if this square is not occupied  AND
                        !board.getTile(candidateDestinationCoordinate).isTileOccupied()){ //and the square we want to go in this case double jump , is also free
                    legalMoves.add(new Move.MajorMove(board,this,candidateDestinationCoordinate));//we can go there
                }
                // if offset = 7 AND our pawn position is NOT in 8th-column-white OR NOT in 1st-column-black (we skip if in 8th or 1st with regarding colors)
            }else if(currentCandidateOffSet == 7 &&
                    !((BoardUtils.EIGHT_COLUMN [this.piecePosition] && this.pieceAlliance.isWhite()  ||
                            (BoardUtils.FIRST_COLUMN[this.piecePosition] && this.pieceAlliance.isBlack() )) )){
                if(board.getTile(candidateDestinationCoordinate).isTileOccupied()){//if  square we want to go is occupied ,
                    final Piece pieceOnCandidate = board.getTile(candidateDestinationCoordinate).getPiece();//we save the piece occupying the square in a var called  pieceOnCandidate.
                    if(this.pieceAlliance != pieceOnCandidate.pieceAlliance){//if the color of our piece is different than the alliance of the occupying piece we add an Attack move
                        //TODO MORE WORK HERE
                        legalMoves.add(new Move.AttackMove(board, this, candidateDestinationCoordinate, pieceOnCandidate));
                    }
                }
            }else if(currentCandidateOffSet == 9 &&//if offSet = 9 AND our pawn position is NOT in 1st-column-white OR NOT in 8th-column-black (we skip if in 8th or 1st with regarding colors)
                    !((BoardUtils.FIRST_COLUMN[this.piecePosition] && this.pieceAlliance.isWhite() ||
                            (BoardUtils.EIGHT_COLUMN[this.piecePosition] && this.pieceAlliance.isBlack() )))){
                if(board.getTile(candidateDestinationCoordinate).isTileOccupied()){//if  square we want to go is occupied ,
                    final Piece pieceOnCandidate = board.getTile(candidateDestinationCoordinate).getPiece();//we save the piece occupying the square in a var called  pieceOnCandidate.
                    if(this.pieceAlliance != pieceOnCandidate.pieceAlliance){//if the alliance of our piece is different from the alliance of the occupying piece we add an Attack move
                        //TODO MORE WORK HERE!!!
                        legalMoves.add(new Move.MajorMove(board,this,candidateDestinationCoordinate));
                    }
                }
            }
        }
        return ImmutableList.copyOf(legalMoves);
    }
    @Override
    public String toString(){
        return PieceType.PAWN.toString();
    }


}
