package com.chess.engine.pieces;
import com.chess.engine.Alliance;
import com.chess.engine.board.Board;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.Move;
import com.chess.engine.board.Tile;
import com.google.common.collect.ImmutableList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static com.chess.engine.board.Move.*;

public class Knight extends Piece{
    /*-----------------------------Data-----------------------------------*/
    private  static final int[] CANDIDATE_MOVE_COORDINATES = {-17, -15, -10, -6, 6, 10, 15, 17};

    /*-----------------------------Constructors-----------------------------------*/
    public Knight(Alliance pieceAlliance, final int piecePosition) {
        super(piecePosition, pieceAlliance);
    }

    /*-----------------------------Abstract Methods-----------------------------------*/
    @Override
    public Collection<Move> calculateLegalMoves(final Board board) {
        final List<Move> legalMoves = new ArrayList<>();   //create an array list to store possible moves
        for(final int currentCandidateOffSet : CANDIDATE_MOVE_COORDINATES){//loop through the candidateOffSet array
            final  int candidateDestinationCoordinate = this.piecePosition + currentCandidateOffSet; //Apply the current offset to the current position
            if(BoardUtils.isValidTileCoordinate(candidateDestinationCoordinate)){// check if the candidateDestinationCoordinate is within 0 - 63 bounds
                if( // add all exclusions where the code breaks and handle them
                        isFirstColumnExclusion(this.piecePosition, currentCandidateOffSet) ||
                                isSecondColumnExclusion(this.piecePosition, currentCandidateOffSet) ||
                                isSeventhColumnExclusion(this.piecePosition, currentCandidateOffSet) ||
                                isEightColumnExclusion(this.piecePosition, currentCandidateOffSet)){
                    continue;
                }
                final Tile candidateDestinationTile = board.getTile(candidateDestinationCoordinate);
                if(!candidateDestinationTile.isTileOccupied()){
                    legalMoves.add(new MajorMove(board, this, candidateDestinationCoordinate));
                }else{
                    final Piece pieceAtDestination = candidateDestinationTile.getPiece();
                    final Alliance pieceAlliance = pieceAtDestination.getPieceAlliance();
                    if(this.pieceAlliance != pieceAlliance){
                        legalMoves.add(new AttackMove(board, this, candidateDestinationCoordinate, pieceAtDestination ));
                    }
                }
            }
        }
        return ImmutableList.copyOf(legalMoves);
    }
    @Override
    public String toString(){
        return PieceType.KNIGHT.toString();
    }

    /*-----------------------------Methods-----------------------------------*/
    private static boolean isFirstColumnExclusion(final int currentPosition, final int candidateOffSet){
        return BoardUtils.FIRST_COLUMN [currentPosition ] && (candidateOffSet == -17 || candidateOffSet == -10 ||
                candidateOffSet == 6 || candidateOffSet == 15);
    }
    private static boolean isSecondColumnExclusion(final int currentPosition, final int candidateOffSet){
        return BoardUtils.SECOND_COLUMN[currentPosition] && (candidateOffSet == -10 || candidateOffSet == 6);
    }
    private static boolean isSeventhColumnExclusion(final int currentPosition, final int candidateOffSet){
        return BoardUtils.SEVENTH_COLUMN[currentPosition] && (candidateOffSet == -6 || candidateOffSet == 10);
    }
    private static boolean isEightColumnExclusion(final int currentPosition, final int candidateOffSet){
        return BoardUtils.EIGHT_COLUMN [currentPosition ] && (candidateOffSet == -15 || candidateOffSet == -6 ||
                candidateOffSet == 10 || candidateOffSet == 17);
    }
}
