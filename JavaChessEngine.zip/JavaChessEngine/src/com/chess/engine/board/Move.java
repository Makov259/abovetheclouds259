package com.chess.engine.board;

import com.chess.engine.pieces.Piece;

public abstract class Move {
    /*---------------------------Data------------------------------------*/
    final Board board;
    final Piece movedPiece;
    final int destinationCoordinate;
    /*---------------------------Constructors------------------------------------*/
    private Move(Board board, Piece movedPiece, int destinationCoordinate) {
        this.board = board;
        this.movedPiece = movedPiece;
        this.destinationCoordinate = destinationCoordinate;
    }


    /*---------------------------MajorMove-Class------------------------------------*/
    public static final class MajorMove extends Move{
        /*---------------------------Constructors------------------------------------*/
        public MajorMove(final Board board, final Piece movedPiece,final int destinationCoordinate) {
            super(board, movedPiece, destinationCoordinate);
        }
    }


    /*---------------------------AttackMove-Class------------------------------------*/
    public static final class AttackMove extends Move{
        final Piece attackedPiece;
        /*---------------------------Constructors------------------------------------*/
        public AttackMove(Board board, Piece movedPiece, int destinationCoordinate, Piece attackedPiece) {
            super(board, movedPiece, destinationCoordinate);
            this.attackedPiece = attackedPiece;
        }
    }
}
