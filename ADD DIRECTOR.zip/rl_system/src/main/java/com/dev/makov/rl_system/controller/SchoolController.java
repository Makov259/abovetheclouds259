package com.dev.makov.rl_system.controller;

import com.dev.makov.rl_system.entity.School;
import com.dev.makov.rl_system.entity.User;
import com.dev.makov.rl_system.service.SchoolService;
import com.dev.makov.rl_system.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class SchoolController {

    @Autowired
    private UserService userService;

    @Autowired
    private SchoolService schoolService;

    @GetMapping("/admin/addSchool")
    public String showAddSchoolForm(Model model) {
        model.addAttribute("school", new School());
        return "admin/addSchool";
    }

    @PostMapping("/admin/addSchoolProcess")
    public String addSchool(@ModelAttribute("school") School school) {
        userService.addSchool(school);
        return "redirect:/admin/home";
    }


    @GetMapping("/school/list")
    public String showSchools(Model model){
        List<School> schools = schoolService.findAll();
        model.addAttribute("schools", schools);
        return "/school/list-schools";
    }

    @GetMapping("/school/addDirector")
    public String showAddDirectorForm(@RequestParam("school_id") Long schoolId, Model model) {
        User director = new User();
        model.addAttribute("director", director);
        model.addAttribute("schoolId", schoolId);
        return "school/addDirector";
    }

    @PostMapping("/school/processAddDirector")
    public String processAddDirector(@ModelAttribute("director") User director, @RequestParam("schoolId") Long schoolId, Model model) {
        // Fetch the school
        School school = schoolService.findById(schoolId);

        // Register the director with the associated school
        userService.registerDirector(director, school);

        // Associate director with the school
        school.setDirector(director);
        schoolService.save(school);

        return "redirect:/school/list";
    }

}
