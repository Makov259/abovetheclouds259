package com.dev.makov.rl_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RlSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(RlSystemApplication.class, args);
	}

}
