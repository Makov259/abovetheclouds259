<?php 
session_start();
include_once "php/config.php"; 

$logged_in_user_id = $_SESSION['unique_id']; 


$other_user_id = null;
$result = null;

// Check if user_id is present in the URL
if(isset($_GET['user_id'])) {
    $other_user_id = $_GET['user_id']; // The ID of the user you are chatting with

    // Fetch messages from the database along with the sender's nickname
    $stmt = $conn->prepare("
        SELECT messages.*, users.nickname 
        FROM messages 
        JOIN users ON messages.outgoing_id = users.unique_id 
        WHERE (incoming_id = ? AND outgoing_id = ?) OR (incoming_id = ? AND outgoing_id = ?) 
        ORDER BY messages.msg_id ASC
    ");
    $stmt->bind_param('iiii', $logged_in_user_id, $other_user_id, $other_user_id, $logged_in_user_id);
    $stmt->execute();
    $result = $stmt->get_result();
} 
?>
<?php include_once "headers/chatHeader.php"; ?>
<!--Start with the HTML-->
<body>

<div id="chat-container">
    <div id="message-area">
        <?php
        // Check if there are any messages
        if($result && $result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $sender_name = htmlspecialchars($row['nickname']); // Get the sender's name
                $message_content = htmlspecialchars($row['message_content']); // Get the message content
                // Display the message with the sender's name
                echo "<div class='message'><strong>{$sender_name}:</strong> {$message_content}</div>";
            }
        } else {
            echo "<div class='no-messages'>No messages yet.</div>";
        }
        ?>
    </div>
    <div id="input-area">
        <form action="php/sendMessage.php" method="post">
            <input type="text" name="message" placeholder="Type a message..." required>
            <input type="hidden" name="outgoing_id" value="<?php echo $logged_in_user_id; ?>">
            <input type="hidden" name="incoming_id" value="<?php echo $other_user_id; ?>">
            <button type="submit" name="send">Send</button>
        </form>
    </div>
</div>

</body>
</html>
