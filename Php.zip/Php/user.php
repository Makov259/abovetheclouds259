<?php session_start(); ?> 

<?php include_once "headers/header.php"; ?> 

<body>
    <div class="wrapper">
        <section class="users">
            <header>
                <?php
                  include_once "php/config.php"; 
                  $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}"); 
                  if(mysqli_num_rows($sql) > 0){ 
                    $row = mysqli_fetch_assoc($sql); 
                  }
                ?>
                <!--Display logged user-->
                <div class="content">
                    <img src="php/images/<?php echo $row['image']?>" alt=""> 
                    <div class="details">
                        <span><?php echo $row['nickname'] ?></span> 
                        <p><?php echo $row['status'] ?></p> 
                    </div>
                </div>
                <a href="php/logout.php?logout_id=<?php echo $row['unique_id'] ?>" class="logout">Logout</a> 
            </header>
            <div class="users-list">
                <?php
                    // Fetch and display other users
                    $usersSql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id != {$_SESSION['unique_id']}"); 
                    if(mysqli_num_rows($usersSql) > 0){ 
                        while($userRow = mysqli_fetch_assoc($usersSql)) { 
                            echo '<div class="user">';
                            echo '<a href="chat.php?user_id=' . $userRow['unique_id'] . '">'; 
                            echo '<img src="php/images/' . $userRow['image'] . '" alt="">'; 
                            echo '<div class="details">'; 
                            echo '<span>' . $userRow['nickname'] . '</span>'; 
                            echo '</div>'; 
                            echo '</a>'; 
                            echo '</div>'; 
                        }
                    }
                ?>
            </div>
        </section>
    </div>

    <!--<script src="javascript/users.js"></script> -->
</body>
</html>
