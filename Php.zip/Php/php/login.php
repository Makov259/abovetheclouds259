<?php 
session_start();
include_once "config.php";
$email = mysqli_real_escape_string($conn, $_POST['email']);//retrieve email from AJAX request.
$password = mysqli_real_escape_string($conn, $_POST['password']);//retrieve password from AJAX request.



if(!empty($email) && !empty($password)){
    $sql = mysqli_query($conn, "SELECT * FROM users WHERE email = '{$email}' AND password = '{$password}'");//we check if the retrieved email and pswrd match a pair in our db
    if(mysqli_num_rows($sql) > 0){//if it matches 
        $row = mysqli_fetch_assoc($sql);//take the specific user's rows and fetch them to the array $row so we can acces them easily row['property'].
        $status = "Active now";
        $sql_2 = mysqli_query($conn, "UPDATE users SET status = '{$status}' WHERE unique_id={$row['unique_id']}");//update our logged in user's status to Active now
        if($sql_2){
            $_SESSION['unique_id'] = $row['unique_id'];
            echo "successful";
        }
    }else{
        echo "Email or Password is Incorrect!";
    }
}else{
    echo "All input fields are required";
}
?>