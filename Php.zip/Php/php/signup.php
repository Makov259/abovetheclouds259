<?php 
session_start();
include_once "config.php";

$nickname = mysqli_real_escape_string($conn, $_POST['nickname']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);


if(!empty($nickname) && !empty($email) && !empty($password)){
    if(filter_var($email, FILTER_VALIDATE_EMAIL)){
        $sql = mysqli_query($conn, "SELECT email FROM users WHERE email = '{$email}'");
        if(mysqli_num_rows($sql) > 0){
            echo "Email already exists!";
        }else{

            if(isset($_FILES['image'])){
                $img_name = $_FILES['image']['name']; //getting the user's uploaded img name,STORING THE ORIGINAL image name
                $tmp_name = $_FILES['image']['tmp_name']; //using this temporary name to save/move file in my folder

                //explode image and get the extension at the end  ,for example png, jpg, etc.  
                $img_explode = explode('.', $img_name);//separate extension from name
                $img_ext = end($img_explode);//get the separated extension from the img

                $extensions = ['png', 'jpeg', 'jpg'];//allowed extensions
                if(in_array($img_ext, $extensions) === true){//if the extension of the uploaded img is within the allowed ones
                    $time = time();//current time


                    $new_img_name = $time.$img_name; //setting unique img name
                    
                    if(move_uploaded_file($tmp_name, "images/".$new_img_name)){//if user uploaded img move it to my folder successfully!
                        $status = "Active now";//setting status
                        $random_id = rand(time(), 10000000);//setting rand id


                        //insert user's data inside the table
                        $sql2 = mysqli_query($conn, "INSERT INTO users (unique_id, nickname, email, password, image, status)
                             VALUES ('{$random_id}', '{$nickname}','{$email}', '{$password}', '{$new_img_name}', '{$status}')");


                        //if inserted successfully 
                        if($sql2){
                            $sql3 = mysqli_query($conn, "SELECT * FROM users WHERE email = '{$email}'");
                            if(mysqli_num_rows($sql3) > 0){
                                $row = mysqli_fetch_assoc($sql3);
                                $_SESSION['unique_id'] = $row['unique_id']; //create new session id ,because our user is going to be redirected to users page, and he will be active
                                echo "successful";
                            }
                        }else{
                            echo "Something went wrong!";

                        }
                    }
                }else{
                    echo "Please select a proper image file:png, jpeg, jpg!";

                }
            }else{
                echo "Please select an image!";
            }
            
        }
    }else{
        echo "$email - This is not a valid email!";
     }
}else{
    echo "All input fields are required!";
   }
?>