<?php
declare(strict_types=1);

function bulsAndCows(int $baseInput, int $tryInput): array {
    $bulls = 0;
    $cows = 0;
    
    $baseDigits = str_split(strval($baseInput));
    $guessDigits = str_split(strval($tryInput));
    
    // Array to keep track of digits already counted as bulls or cows
    $usedBaseDigits = array_fill(0, 4, false);
    $usedGuessDigits = array_fill(0, 4, false);
    
    // First pass to count bulls
    for ($m = 0; $m < 4; $m++) {
        if ($baseDigits[$m] === $guessDigits[$m]) {
            $bulls++;
            $usedBaseDigits[$m] = true;
            $usedGuessDigits[$m] = true;
        }
    }
    
    // Second pass to count cows
    for ($i = 0; $i < 4; $i++) {
        if (!$usedGuessDigits[$i]) {
            for ($j = 0; $j < 4; $j++) {
                if (!$usedBaseDigits[$j] && $baseDigits[$j] === $guessDigits[$i]) {
                    $cows++;
                    $usedBaseDigits[$j] = true;
                    break;
                }
            }
        }
    }
    
    return ["buls" => $bulls, "cows" => $cows];
}
