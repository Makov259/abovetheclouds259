<?php 
session_start();
include_once "config.php"; 

if(isset($_POST['send'], $_POST['message'], $_POST['outgoing_id'], $_POST['incoming_id'])) {
    // Capture the incoming and outgoing IDs
    $outgoing_id = $_POST['outgoing_id'];
    $incoming_id = $_POST['incoming_id'];
    $message = trim($_POST['message']);

    // Insert the message into the database
    $stmt = $conn->prepare("INSERT INTO messages (incoming_id, outgoing_id, message_content) VALUES (?, ?, ?)");
    $stmt->bind_param('iis', $incoming_id, $outgoing_id, $message);
        $stmt-> execute();

        if($stmt->affected_rows > 0){
            // Redirect back to chat.php with the ID of the user you are chatting with
            header("location: ../chat.php?user_id=" . $incoming_id);
        }
        $stmt->close();
}
?>