<?php include_once "headers/header.php"; ?> 
<body>
    <div class="wrapper">
        <section class="signup form">
            <header>Chat Application</header>
            <form action="#" enctype="multipart/form-data">
                <div class="error-message"></div>
                <div class="user-details">
                    <div class="input field">
                        <label>Nickname</label>
                        <input type="text" name="nickname" placeholder="Nickname" required>
                    </div>
                    <div class="input field">
                        <label>Email</label>
                        <input type="text" name="email" placeholder="Enter your Email" required>
                    </div>
                    <div class="input field">
                        <label>Password</label>
                        <input type="text" name="password" placeholder="Enter your Password" required>
                        <i class="fas fa-eye"></i>
                    </div>
                    <div class="input field">
                        <label>Select an Image</label>
                        <input type="file" name="image" required>
                    </div>
                    <div class="submit-button-field">
                        <input type="submit" value="Continue">
                    </div>
                </div>
            </form>
            <div class="link">Already Have an Account?<a href="login.php">Login now</a></div>
        </section>
    </div>

    <script src="javascript/signUp.js"></script>

</body>
</html>