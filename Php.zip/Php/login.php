<?php include_once "headers/header.php"; ?> 
<body>
    <div class="wrapper">
        <section class="login form">
            <header>Makov'Chat Application</header>
            <form action="#" >
                <div class="error-message"></div>
                <div class="user-details">
                    <div class="input field">
                        <label>Email</label>
                        <input type="text" name="email" placeholder="Enter your Email" required>
                    </div>
                    <div class="input field">
                        <label>Password</label>
                        <input type="text" name="password" placeholder="Enter your Password" required>
                    </div>
                    <div class="submit-button-field">
                        <input type="submit" value="Continue">
                    </div>
                </div>
            </form>
            <div class="link">Don't Have an Account?<a href="index.php">Signup now</a></div>
        </section>
    </div>

    <script src="javascript/login.js"></script>

</body>
</html>