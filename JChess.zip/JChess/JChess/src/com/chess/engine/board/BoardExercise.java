package com.chess.engine.board;

public class BoardExercise {


    public static void main(String[] args){

    }
}
