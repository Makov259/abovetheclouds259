package com.dev.makov.rl_system.dao;

import com.dev.makov.rl_system.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByEmail(String email);

    @Transactional
    @Modifying
    @Query(value = "UPDATE user_roles SET role_name = :roleName WHERE user_id = :userId AND role_id = :roleId", nativeQuery = true)
    void updateUserRoleName(Long userId, Long roleId, String roleName);


}
