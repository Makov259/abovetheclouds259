package com.dev.makov.rl_system.dao;

import com.dev.makov.rl_system.entity.SchoolSubject;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SchoolSubjectRepository extends JpaRepository<SchoolSubject, Long> {
    // Custom queries if needed
}