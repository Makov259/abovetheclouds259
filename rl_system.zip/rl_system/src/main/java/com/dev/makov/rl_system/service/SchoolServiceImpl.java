package com.dev.makov.rl_system.service;

import com.dev.makov.rl_system.dao.SchoolRepository;
import com.dev.makov.rl_system.entity.School;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SchoolServiceImpl implements SchoolService {

    private SchoolRepository schoolRepository;

    @Autowired
    public SchoolServiceImpl(SchoolRepository schoolRepository) {
        this.schoolRepository = schoolRepository;
    }

    @Override
    public List<School> findAll() {
        return schoolRepository.findAll();
    }

    @Override
    public School findById(Long id) {
        Optional<School> result = schoolRepository.findById(id);
        School school = null;
        if (result.isPresent()) {
            school = result.get();
        } else {
            throw new RuntimeException("Did not find school id - " + id);
        }
        return school;
    }

    @Override
    public School save(School school) {
        return schoolRepository.save(school);
    }

    @Override
    public void deleteById(Long id) {
        schoolRepository.deleteById(id);
    }
}
