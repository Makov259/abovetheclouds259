package com.dev.makov.rl_system.controller;

import com.dev.makov.rl_system.entity.School;
import com.dev.makov.rl_system.entity.User;
import com.dev.makov.rl_system.service.SchoolService;
import com.dev.makov.rl_system.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class SchoolController {

    @Autowired
    private UserService userService;

    @Autowired
    private SchoolService schoolService;

    @GetMapping("/admin/addSchool")
    public String showAddSchoolForm(Model model) {
        model.addAttribute("school", new School());
        return "admin/addSchool";
    }

    @PostMapping("/admin/addSchoolProcess")
    public String addSchool(@ModelAttribute("school") School school) {
        userService.addSchool(school);
        return "redirect:/admin/home";
    }


    @GetMapping("/school/list")
    public String showSchools(Model model){
        List<School> schools = schoolService.findAll();
        model.addAttribute("schools", schools);
        return "/school/list-schools";
    }

    @GetMapping("/school/addDirector")
    public String showAddDirectorForm(@RequestParam("school_id") Long schoolId, Model model) {
        User director = new User();
        model.addAttribute("director", director);
        model.addAttribute("schoolId", schoolId);
        return "director/addDirector";
    }

    @PostMapping("/school/processAddDirector")
    public String processAddDirector(@ModelAttribute("director") User director, @RequestParam("schoolId") Long schoolId, Model model) {
        // Fetch the school
        School school = schoolService.findById(schoolId);

        // Register the director with the associated school
        userService.registerDirector(director, school);

        // Associate director with the school
        school.setDirector(director);
        schoolService.save(school);

        return "redirect:/school/list";
    }

    @GetMapping("/school/updateDirector")
    public String showUpdateDirectorForm(@RequestParam("director_id") Long directorId, Model model) {
        User director = userService.findById(directorId);
        model.addAttribute("director", director);
        return "director/updateDirector";
    }

    @PostMapping("/school/processUpdateDirector")
    public String processUpdateDirector(@ModelAttribute("director") User director) {
        // Update the director information
        userService.updateDirector(director);
        return "redirect:/school/list";
    }

    @GetMapping("/school/deleteDirector")
    public String deleteDirector(@RequestParam("director_id") Long directorId, @RequestParam("school_id") Long schoolId) {
        if (directorId != 0) {
            // Delete the director from the user table
            userService.deleteDirector(directorId);

            // Remove the director from the school table
            School school = schoolService.findById(schoolId);
            if (school != null) {
                school.setDirector(null);
                schoolService.save(school);
            }
        }

        return "redirect:/school/list";
    }

    @GetMapping("/school/displayDirector")
    public String displayDirector(@RequestParam("director_id") Long directorId, Model model){
       User director = userService.findById(directorId);
       model.addAttribute("director", director);
       return "director/displayDirector";
    }

    @GetMapping("/school/addTeacher")
    public String showAddTeacherForm(@RequestParam("school_id") Long schoolId, Model model) {
        User teacher = new User();
        model.addAttribute("teacher", teacher);
        model.addAttribute("schoolId", schoolId);
        return "teacher/addTeacher";
    }

    @PostMapping("/school/processAddTeacher")
    public String processAddTeacher(@ModelAttribute("teacher") User teacher, @RequestParam("schoolId") Long schoolId, Model model) {
        // Fetch the school
        School school = schoolService.findById(schoolId);

        // Set the school for the teacher
        teacher.setSchool(school);

        // Register the teacher as a user
        userService.registerTeacher(teacher);

        // Associate the teacher with the school (this might not be necessary if the relationship is bidirectional)
        schoolService.addTeacherToSchool(teacher, school);

        return "redirect:/school/list";
    }

    @GetMapping("/school/updateTeacher")
    public String showUpdateTeacherForm(@RequestParam("school_id") Long schoolId, Model model) {
        User teacher = new User();
        model.addAttribute("teacher", teacher);
        model.addAttribute("schoolId", schoolId);
        return "teacher/updateTeacher";
    }

    @PostMapping("/school/processUpdateTeacher")
    public String processUpdateTeacher(@ModelAttribute("teacher") User teacher) {
        // Update the teacher information
        userService.updateTeacher(teacher);
        return "redirect:/school/list";
    }

    @GetMapping("/school/deleteTeacher")
    public String showDeleteTeacherForm(@RequestParam("school_id") Long schoolId, Model model) {
        model.addAttribute("schoolId", schoolId);
        return "teacher/deleteTeacher";
    }

    @PostMapping("/school/processDeleteTeacher")
    public String processDeleteTeacher(@RequestParam("teacherId") Long teacherId, @RequestParam("schoolId") Long schoolId) {
        // Remove the teacher from the school_teachers table
        schoolService.removeTeacherFromSchool(teacherId, schoolId);

        // Delete the teacher from the user table
        userService.deleteTeacher(teacherId);

        return "redirect:/school/list";
    }

    @GetMapping("/school/displayTeachers")
    public String displayTeachers(@RequestParam("school_id") Long schoolId, Model model) {
        // Fetch the school
        School school = schoolService.findById(schoolId);

        // Get the list of teachers
        List<User> teachers = userService.findTeachersBySchool(schoolId);
        model.addAttribute("teachers", teachers);

        return "teacher/displayTeachers";
    }
}
