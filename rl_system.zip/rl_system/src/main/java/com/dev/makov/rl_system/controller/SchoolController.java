package com.dev.makov.rl_system.controller;

import com.dev.makov.rl_system.entity.School;
import com.dev.makov.rl_system.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class SchoolController {

    @Autowired
    private UserService userService;

    @GetMapping("/admin/addSchool")
    public String showAddSchoolForm(Model model) {
        model.addAttribute("school", new School());
        return "admin/addSchool";
    }

    @PostMapping("/admin/addSchoolProcess")
    public String addSchool(@ModelAttribute("school") School school) {
        userService.addSchool(school);
        return "redirect:/admin/home";
    }
}
