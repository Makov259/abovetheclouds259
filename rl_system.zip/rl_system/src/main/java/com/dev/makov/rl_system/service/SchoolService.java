package com.dev.makov.rl_system.service;

import com.dev.makov.rl_system.entity.School;

import java.util.List;

public interface SchoolService {
    List<School> findAll();
    School findById(Long id);
    School save(School school);
    void deleteById(Long id);
}
