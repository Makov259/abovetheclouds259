package com.dev.makov.rl_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RlSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
