package com.simpleform.service;

public class AdminService {

}
