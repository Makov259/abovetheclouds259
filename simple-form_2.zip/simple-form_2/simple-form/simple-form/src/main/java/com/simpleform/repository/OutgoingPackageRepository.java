package com.simpleform.repository;

import com.simpleform.entity.OutgoingPackage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OutgoingPackageRepository extends JpaRepository<OutgoingPackage, Integer> {

}
